Before Running The Python Program Pls Do Upload 3 CSV{Excel Sheets} files(As it contains data related to user,books and ratings)In this program we are fetching data from these three csv files
http://www2.informatik.uni-freiburg.de/~cziegler/BX/ u can download it from here(and rename ratingbx with rating,userbx with users and booksbx with books
